package org.thunms.tasks.jobjars.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.dao.Dao;
import org.thunms.framework.service.ServiceSupport;
import org.thunms.tasks.jobjars.dao.TaskJobjarDao;
import org.thunms.tasks.jobjars.entity.TaskJobjarEntity;
import org.thunms.tasks.jobjars.model.TaskJobjar;
import org.thunms.platform.common.entity.UserEntity;
import org.thunms.platform.organizations.entity.AreaEntity;
import org.thunms.platform.organizations.entity.DepartmentEntity;
/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
@Service
public class TaskJobjarService extends ServiceSupport<TaskJobjarEntity,TaskJobjar>  {
	private static final Logger logger=LoggerFactory.getLogger(TaskJobjarService.class);
	@Autowired
	private TaskJobjarDao taskJobjarDao;

	@Override
	protected Dao<TaskJobjarEntity> getBaseDao() {
		return this.taskJobjarDao;
	}
	
	
}
