package org.thunms.tasks.jobjars.entity;

import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.FetchType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.thunms.framework.entity.EntitySupport;

/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
@Entity
public class TaskJobjarEntity extends EntitySupport {

	

	
	

}
