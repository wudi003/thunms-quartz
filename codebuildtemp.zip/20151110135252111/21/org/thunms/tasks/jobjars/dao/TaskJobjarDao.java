package org.thunms.tasks.jobjars.dao;

import org.springframework.stereotype.Repository;
import org.thunms.framework.dao.DaoSupport;
import org.thunms.tasks.jobjars.entity.TaskJobjarEntity;
/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
@Repository
public class TaskJobjarDao extends DaoSupport<TaskJobjarEntity> {

}
