package org.thunms.tasks.configs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.dao.Dao;
import org.thunms.framework.service.ServiceSupport;
import org.thunms.tasks.configs.dao.TaskConfigDao;
import org.thunms.tasks.configs.entity.TaskConfigEntity;
import org.thunms.tasks.configs.model.TaskConfig;
import org.thunms.platform.common.entity.UserEntity;
import org.thunms.platform.organizations.entity.AreaEntity;
import org.thunms.platform.organizations.entity.DepartmentEntity;
/**
 * 任务资源管理
 * 全局配置管理
 * 配置信息维护
 */
@Service
public class TaskConfigService extends ServiceSupport<TaskConfigEntity,TaskConfig>  {
	private static final Logger logger=LoggerFactory.getLogger(TaskConfigService.class);
	@Autowired
	private TaskConfigDao taskConfigDao;

	@Override
	protected Dao<TaskConfigEntity> getBaseDao() {
		return this.taskConfigDao;
	}
	
	
}
