package org.thunms.tasks.configs.dao;

import org.springframework.stereotype.Repository;
import org.thunms.framework.dao.DaoSupport;
import org.thunms.tasks.configs.entity.TaskConfigEntity;
/**
 * 任务资源管理
 * 全局配置管理
 * 配置信息维护
 */
@Repository
public class TaskConfigDao extends DaoSupport<TaskConfigEntity> {

}
