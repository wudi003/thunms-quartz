package org.thunms.tasks.configs.model;
import java.util.Date;
import java.math.BigDecimal;
import org.thunms.framework.model.ModelSupport;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.thunms.framework.utils.JsonYearDateSerializer;import org.thunms.framework.utils.JsonDateTimeSerializer;import org.thunms.framework.utils.JsonDateSerializer;import org.thunms.framework.utils.JsonTimeSerializer;import org.thunms.framework.utils.JsonYearDateTimeSerializer;
/**
 * 任务资源管理
 * 全局配置管理
 * 配置信息维护
 */
public class TaskConfig extends ModelSupport {
	
	/**
	 *名称
	**/
	private String name;
	/**
	 *内容
	**/
	private String value;
	
	/**
	 *获取_名称_的值.
	**/
	public String getName() {
		return this.name;
	}
	/**
	 *设置_名称_的值.
	**/
	public void setName(String name) {
		this.name = name;
	}
	/**
	 *获取_内容_的值.
	**/
	public String getValue() {
		return this.value;
	}
	/**
	 *设置_内容_的值.
	**/
	public void setValue(String value) {
		this.value = value;
	}

	
	

}
