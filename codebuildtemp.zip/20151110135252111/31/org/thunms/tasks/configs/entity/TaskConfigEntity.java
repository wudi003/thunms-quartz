package org.thunms.tasks.configs.entity;

import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.FetchType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.thunms.framework.entity.EntitySupport;

/**
 * 任务资源管理
 * 全局配置管理
 * 配置信息维护
 */
@Entity
public class TaskConfigEntity extends EntitySupport {

	/**
	 *名称
	**/
	private String name;
	/**
	 *内容
	**/
	private String value;
	
	/**
	 *获取_名称_的值.
	**/
	public String getName() {
		return this.name;
	}
	/**
	 *设置_名称_的值.
	**/
	public void setName(String name) {
		this.name = name;
	}
	/**
	 *获取_内容_的值.
	**/
	public String getValue() {
		return this.value;
	}
	/**
	 *设置_内容_的值.
	**/
	public void setValue(String value) {
		this.value = value;
	}

	
	

}
