package org.thunms.tasks.configs.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thunms.framework.controller.ControllerDataGrid;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.Json;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.service.ServiceDefault;
import org.thunms.tasks.configs.entity.TaskConfigEntity;
import org.thunms.tasks.configs.model.TaskConfig;
import org.thunms.tasks.configs.service.TaskConfigService;
/**
 * 任务资源管理
 * 全局配置管理
 * 配置信息维护
 */
@Controller
@RequestMapping("/tasks/configs/taskConfig")
public class TaskConfigController extends ControllerDataGrid<TaskConfigEntity,TaskConfig> {
	
	private static final Logger logger =LoggerFactory.getLogger(TaskConfigController.class);

	public TaskConfigController() {
		super("tasks", "configs", "taskConfig");
		logger.debug("执行模块初始化"+this.getRerutnURL(""));
	}
	
	@Autowired
	private TaskConfigService taskConfigService;

	@Override
	protected ServiceDefault<TaskConfigEntity, TaskConfig> getBaseService() {
		return this.taskConfigService;
	}
	

}
