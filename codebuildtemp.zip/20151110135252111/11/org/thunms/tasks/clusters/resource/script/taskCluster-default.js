/**
 * 任务资源管理
 * 集群任务管理
 * 集群任务维护
 */
/**
 * 
 * 这是代码生成出来的js，原则上不建议修改此文件.
 * 
 **/
var taskClusterDataGrid;
	$(function() {
		taskClusterDataGrid = $('#taskClusterDataGrid').datagrid({
			url : thunms.base()+'/tasks/clusters/taskCluster/dataGridList',
			toolbar : '#toolbar',
			title : '信息列表',
			pagination : true,
			pageSize : 100,
			pageList : [ 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 ],
			fit : true,
			fitColumns : true,
			nowrap : false,
			border : false,
			idField : 'id',
			frozenColumns : [ [ {
				title : 'id',
				field : 'id',
				width : 50,
				checkbox : true
			} ] ],
			columns : [ [
				{
				field : 'name',
				title : '任务名称',
				width : 150,
				sortable : true
			}, 
				{
				field : 'command',
				title : '任务命令',
				width : 150,
				sortable : true
			}, 
			{
				field : 'createUserName',
				title : '创建者',
				width : 150,
				sortable : true
			} , {
				field : 'createTime',
				title : '创建时间',
				width : 150,
				sortable : true
			}, {
				field : 'lastUpdateTime',
				title : '最后修改时间',
				width : 150,
				sortable : true
			}] ],
			onRowContextMenu : function(e, rowIndex, rowData) {
				e.preventDefault();
				$(this).datagrid('unselectAll');
				$(this).datagrid('selectRow', rowIndex);
				$('#menu').menu('show', {
					left : e.pageX,
					top : e.pageY
				});
			}
		});

	});
	
	
	function taskClusterAppend() {
    var p = parent.thunms.dialog({
                href : thunms.base() + '/tasks/clusters/taskCluster/add',
                title : '新增信息',
                width : $(document.body).width(),
                height : $(document.body).height(),
                buttons : [{
                            text : '保存',
                            handler : function() {
                                parent.thunms.confirm('请确认', '您要保存当前新增的信息？', function(r) {
                                            if (r) {
                                            	parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
                                                var f = p.find('#taskClusterAddForm');
                                                f.form('submit', {
                                                            url : thunms.base() + '/tasks/clusters/taskCluster/addSave',
                                                            onSubmit: function(){
	                                                            //验证表单,可以在此增加其他的验证。
																if(f.form("validate")){
																
																	return true;//返回true时表示验证通过
																}else{
																	parent.thunms.progress.close();//关闭提示窗口
																	return false;//返回false表示验证未通过
																}
															},
                                                            success : function(d) {
                                                                var json = $.parseJSON(d);
                                                                if (json.success) {
                                                                    taskClusterDataGrid.datagrid('reload');
                                                                    p.dialog('close');
                                                                }
                                                                parent.thunms.progress.close();
                                                                parent.thunms.show({
                                                                            msg : json.msg,
                                                                            title : '提示'
                                                                        });
                                                            }
                                                        });
                                            }
                                        });
                            }
                        }, {
                            text : '取消',
                            handler : function() {
                                parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                            if (r) {
                                                p.dialog('close');
                                            }
                                        });
                                
                            }
                        }],
                    onLoad : function() {
                        var f = p.find('#taskClusterAddForm');
                        //加载数据
                        //f.form('load',{});
                    }
            });
  }

	function taskClusterEdit() {
    var rows = taskClusterDataGrid.datagrid('getSelections');
    if (rows.length != 1 && rows.length != 0) {
        parent.thunms.show({
                    msg : '只能择一条进行修改！您已经选择了' + rows.length + '条数据',
                    title : '提示'
                });
    } else if (rows.length == 1) {
        var p = parent.thunms.dialog({
                    title : '编辑信息',
                    href : thunms.base() + '/tasks/clusters/taskCluster/update',
                    width : $(document.body).width(),
                    height : $(document.body).height(),
                    buttons : [{
                                text : '保存',
                                handler : function() {
                                    parent.thunms.confirm('请确认', '您要保存当前修改的信息？', function(r) {
                                                if (r) {
                                                	parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
                                                    var f = p.find('#taskClusterUpdateForm');
                                                    f.form('submit', {
                                                                url : thunms.base() + '/tasks/clusters/taskCluster/updateSave?id=' + rows[0].id,
                                                                onSubmit: function(){
		                                                            //验证表单,可以在此增加其他的验证。
																	if(f.form("validate")){
																	
																		return true;//返回true时表示验证通过
																	}else{
																		parent.thunms.progress.close();//关闭提示窗口
																		return false;//返回false表示验证未通过
																	}
																},
                                                                success : function(d) {
                                                                    var json = $.parseJSON(d);
                                                                    if (json.success) {
                                                                        taskClusterDataGrid.datagrid('reload');
                                                                        p.dialog('close');
                                                                    }
                                                                    parent.thunms.progress.close();
                                                                    parent.thunms.show({
                                                                                msg : json.msg,
                                                                                title : '提示'
                                                                            });
                                                                }
                                                            });
                                                }
                                            });
                                }
                            }, {
                                text : '取消',
                                handler : function() {
                                    parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                                if (r) {
                                                    p.dialog('close');
                                                }
                                            });
                                    
                                }
                            }],
                    onLoad : function() {
                        var f = p.find('#taskClusterUpdateForm');
                        f.form('load', thunms.base() + '/tasks/clusters/taskCluster/findByPrimaryKey?id=' + rows[0].id);
                        
                    }
                });
        
    } else {
        parent.thunms.show({
                    msg : '请选择需要修改的数据',
                    title : '提示'
                });
    }
	}
	function taskClusterRemove() {
		var ids = [];
		var rows = taskClusterDataGrid.datagrid('getSelections');
		if (rows.length > 0) {
			parent.thunms.confirm('请确认', '您要删除当前所选数据？', function(r) {
				if (r) {
					parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
					for ( var i = 0; i < rows.length; i++) {
						ids.push(rows[i].id);
					}
					$.ajax({
						url :  thunms.base()+'/tasks/clusters/taskCluster/deleteAll',
						data : {
							ids : ids.join(',')
						},
						cache : false,
						dataType : "json",
						success : function(msg) {
							taskClusterDataGrid.datagrid('unselectAll');
							taskClusterDataGrid.datagrid('reload');
							parent.thunms.progress.close();
							parent.thunms.show({
								title : '提示',
								msg : msg.msg
							});
						}
					});
				}
			});
		} else {
			parent.thunms.alert('提示', '请选择要删除的记录！', 'error');
		}
	}

	function searchFun() {
		taskClusterDataGrid.datagrid('load', $("#taskClusterSearchForm").serializeObject());
	}
	function clearFun() {
		$("#taskClusterSearchForm").form("clear");
		taskClusterDataGrid.datagrid('load', {});
	}
	function taskClusterSearchFun(){
		var p = parent.thunms.dialog({
                    title : '高级查询',
                    href : thunms.base() + '/tasks/clusters/taskCluster/query',
                    width : $(document.body).width(),
                    height : $(document.body).height(),
                    buttons : [{
                                text : '查询',
                                handler : function() {
                                    parent.thunms.confirm('请确认', '您要执行当前查询？', function(r) {
                                                if (r) {
                                                    var f = p.find('#taskClusterSearchForm');
                                                    taskClusterDataGrid.datagrid('load', f.serializeObject());
                                                     p.dialog('close');
                                                }
                                            });
                                }
                            },{
                                text : '取消',
                                handler : function() {
                                    parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                                if (r) {
                                                    p.dialog('close');
                                                }
                                            });
                                    
                                }
                            }]
                });
	}
	function taskClusterLook() {
    var rows = taskClusterDataGrid.datagrid('getSelections');
    if (rows.length != 1 && rows.length != 0) {
        parent.thunms.show({
                    msg : '只能择一条进行查看！您已经选择了' + rows.length + '条数据',
                    title : '提示'
                });
    } else if (rows.length == 1) {
        var p = parent.thunms.dialog({
                    title : '信息查看',
                    href : thunms.base() + '/tasks/clusters/taskCluster/look',
                    width : $(document.body).width(),
                    height : $(document.body).height(),
                    buttons : [{
                                text : '取消',
                                handler : function() {
                                    parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                                if (r) {
                                                    p.dialog('close');
                                                }
                                            });
                                    
                                }
                            }],
                    onLoad : function() {
                        var f = p.find('#taskClusterLookForm');
                        f.form('load', thunms.base() + '/tasks/clusters/taskCluster/findByPrimaryKey?id=' + rows[0].id);
                        
                    }
                });
        
    } else {
        parent.thunms.show({
                    msg : '请选择需要查看的数据',
                    title : '提示'
                });
    }
	}