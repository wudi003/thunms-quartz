package org.thunms.tasks.clusters.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.dao.Dao;
import org.thunms.framework.service.ServiceSupport;
import org.thunms.tasks.clusters.dao.TaskClusterDao;
import org.thunms.tasks.clusters.entity.TaskClusterEntity;
import org.thunms.tasks.clusters.model.TaskCluster;
import org.thunms.platform.common.entity.UserEntity;
import org.thunms.platform.organizations.entity.AreaEntity;
import org.thunms.platform.organizations.entity.DepartmentEntity;
/**
 * 任务资源管理
 * 集群任务管理
 * 集群任务维护
 */
@Service
public class TaskClusterService extends ServiceSupport<TaskClusterEntity,TaskCluster>  {
	private static final Logger logger=LoggerFactory.getLogger(TaskClusterService.class);
	@Autowired
	private TaskClusterDao taskClusterDao;

	@Override
	protected Dao<TaskClusterEntity> getBaseDao() {
		return this.taskClusterDao;
	}
	
	
}
