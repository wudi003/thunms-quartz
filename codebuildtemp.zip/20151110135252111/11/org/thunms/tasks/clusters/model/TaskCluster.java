package org.thunms.tasks.clusters.model;
import java.util.Date;
import java.math.BigDecimal;
import org.thunms.framework.model.ModelSupport;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.thunms.framework.utils.JsonYearDateSerializer;import org.thunms.framework.utils.JsonDateTimeSerializer;import org.thunms.framework.utils.JsonDateSerializer;import org.thunms.framework.utils.JsonTimeSerializer;import org.thunms.framework.utils.JsonYearDateTimeSerializer;
/**
 * 任务资源管理
 * 集群任务管理
 * 集群任务维护
 */
public class TaskCluster extends ModelSupport {
	
	/**
	 *任务名称
	**/
	private String name;
	/**
	 *任务命令
	**/
	private String command;
	
	/**
	 *获取_任务名称_的值.
	**/
	public String getName() {
		return this.name;
	}
	/**
	 *设置_任务名称_的值.
	**/
	public void setName(String name) {
		this.name = name;
	}
	/**
	 *获取_任务命令_的值.
	**/
	public String getCommand() {
		return this.command;
	}
	/**
	 *设置_任务命令_的值.
	**/
	public void setCommand(String command) {
		this.command = command;
	}

	
	

}
