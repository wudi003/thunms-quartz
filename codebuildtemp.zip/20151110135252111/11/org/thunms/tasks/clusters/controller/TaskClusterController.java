package org.thunms.tasks.clusters.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thunms.framework.controller.ControllerDataGrid;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.Json;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.service.ServiceDefault;
import org.thunms.tasks.clusters.entity.TaskClusterEntity;
import org.thunms.tasks.clusters.model.TaskCluster;
import org.thunms.tasks.clusters.service.TaskClusterService;
/**
 * 任务资源管理
 * 集群任务管理
 * 集群任务维护
 */
@Controller
@RequestMapping("/tasks/clusters/taskCluster")
public class TaskClusterController extends ControllerDataGrid<TaskClusterEntity,TaskCluster> {
	
	private static final Logger logger =LoggerFactory.getLogger(TaskClusterController.class);

	public TaskClusterController() {
		super("tasks", "clusters", "taskCluster");
		logger.debug("执行模块初始化"+this.getRerutnURL(""));
	}
	
	@Autowired
	private TaskClusterService taskClusterService;

	@Override
	protected ServiceDefault<TaskClusterEntity, TaskCluster> getBaseService() {
		return this.taskClusterService;
	}
	

}
