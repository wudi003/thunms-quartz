package org.thunms.tasks.clusters.dao;

import org.springframework.stereotype.Repository;
import org.thunms.framework.dao.DaoSupport;
import org.thunms.tasks.clusters.entity.TaskClusterEntity;
/**
 * 任务资源管理
 * 集群任务管理
 * 集群任务维护
 */
@Repository
public class TaskClusterDao extends DaoSupport<TaskClusterEntity> {

}
