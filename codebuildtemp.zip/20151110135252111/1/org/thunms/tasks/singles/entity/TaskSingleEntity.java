package org.thunms.tasks.singles.entity;

import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.FetchType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.thunms.framework.entity.EntitySupport;

/**
 * 任务资源管理
 * 单例任务管理
 * 单例任务维护
 */
@Entity
public class TaskSingleEntity extends EntitySupport {

	/**
	 *任务名称
	**/
	private String name;
	/**
	 *任务命令
	**/
	private String command;
	
	/**
	 *获取_任务名称_的值.
	**/
	public String getName() {
		return this.name;
	}
	/**
	 *设置_任务名称_的值.
	**/
	public void setName(String name) {
		this.name = name;
	}
	/**
	 *获取_任务命令_的值.
	**/
	public String getCommand() {
		return this.command;
	}
	/**
	 *设置_任务命令_的值.
	**/
	public void setCommand(String command) {
		this.command = command;
	}

	
	

}
