package org.thunms.tasks.singles.initializing;

import java.util.List;

import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thunms.framework.initializing.InitializingManager;
import org.thunms.framework.initializing.InitializingSupport;
import org.thunms.framework.initializing.ModuleMetadata;
import org.thunms.tasks.singles.dao.TaskSingleDao;
import org.thunms.platform.common.dao.UserDao;
import org.thunms.platform.organizations.dao.AreaDao;
import org.thunms.platform.organizations.dao.DepartmentDao;
/**
 * 任务资源管理
 * 单例任务管理
 * 单例任务维护
 */
/**
 *这是自动生成的，模块数据初始化方法，如果不需要，请去掉类前面的@Component注解就可以了.
 */
@Component
public class TaskSingleInitializing extends InitializingSupport {
	private static final Logger logger=LoggerFactory.getLogger(TaskSingleInitializing.class);
	@Autowired
	private TaskSingleDao taskSingleDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private DepartmentDao departmentDao;
	@Autowired
	private AreaDao areaDao;
	
	

	@Override
	public void initData() {
		/**
		List<ModuleMetadata> menuList = InitializingManager.MenutionList;
		for (ModuleMetadata module : menuList) {
			logger.debug("---------------在这里添加模块自动化初始数据--------------------->>>"+this.getClass().getName());
		}
		**/
	
	}
	@Override
	public void destroy() {
		this.taskSingleDao.clearData();
	}



	@Override
	public String getEntityName() {
		return this.taskSingleDao.getEntityName();
	}
}
