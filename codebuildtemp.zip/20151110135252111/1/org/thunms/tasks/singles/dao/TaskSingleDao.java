package org.thunms.tasks.singles.dao;

import org.springframework.stereotype.Repository;
import org.thunms.framework.dao.DaoSupport;
import org.thunms.tasks.singles.entity.TaskSingleEntity;
/**
 * 任务资源管理
 * 单例任务管理
 * 单例任务维护
 */
@Repository
public class TaskSingleDao extends DaoSupport<TaskSingleEntity> {

}
