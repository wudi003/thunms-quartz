package org.thunms.tasks.singles.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thunms.framework.controller.ControllerDataGrid;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.Json;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.service.ServiceDefault;
import org.thunms.tasks.singles.entity.TaskSingleEntity;
import org.thunms.tasks.singles.model.TaskSingle;
import org.thunms.tasks.singles.service.TaskSingleService;
/**
 * 任务资源管理
 * 单例任务管理
 * 单例任务维护
 */
@Controller
@RequestMapping("/tasks/singles/taskSingle")
public class TaskSingleController extends ControllerDataGrid<TaskSingleEntity,TaskSingle> {
	
	private static final Logger logger =LoggerFactory.getLogger(TaskSingleController.class);

	public TaskSingleController() {
		super("tasks", "singles", "taskSingle");
		logger.debug("执行模块初始化"+this.getRerutnURL(""));
	}
	
	@Autowired
	private TaskSingleService taskSingleService;

	@Override
	protected ServiceDefault<TaskSingleEntity, TaskSingle> getBaseService() {
		return this.taskSingleService;
	}
	

}
