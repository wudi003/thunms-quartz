package org.thunms.tasks.singles.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.dao.Dao;
import org.thunms.framework.service.ServiceSupport;
import org.thunms.tasks.singles.dao.TaskSingleDao;
import org.thunms.tasks.singles.entity.TaskSingleEntity;
import org.thunms.tasks.singles.model.TaskSingle;
import org.thunms.platform.common.entity.UserEntity;
import org.thunms.platform.organizations.entity.AreaEntity;
import org.thunms.platform.organizations.entity.DepartmentEntity;
/**
 * 任务资源管理
 * 单例任务管理
 * 单例任务维护
 */
@Service
public class TaskSingleService extends ServiceSupport<TaskSingleEntity,TaskSingle>  {
	private static final Logger logger=LoggerFactory.getLogger(TaskSingleService.class);
	@Autowired
	private TaskSingleDao taskSingleDao;

	@Override
	protected Dao<TaskSingleEntity> getBaseDao() {
		return this.taskSingleDao;
	}
	
	
}
