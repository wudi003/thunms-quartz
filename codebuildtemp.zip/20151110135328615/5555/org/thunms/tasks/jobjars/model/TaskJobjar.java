package org.thunms.tasks.jobjars.model;

import java.util.Date;
import java.math.BigDecimal;

import org.apache.commons.lang33.builder.ToStringBuilder;
import org.thunms.framework.model.ModelSupport;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.thunms.framework.utils.JsonYearDateSerializer;import org.thunms.framework.utils.JsonDateTimeSerializer;import org.thunms.framework.utils.JsonDateSerializer;import org.thunms.framework.utils.JsonTimeSerializer;import org.thunms.framework.utils.JsonYearDateTimeSerializer;
/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
public class TaskJobjar extends ModelSupport {
	
	private String  name;
	private String parentId;
	private String parentName;
	private String state;
	private String checked;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getChecked() {
		return checked;
	}
	public void setChecked(String checked) {
		this.checked = checked;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	
	

}
