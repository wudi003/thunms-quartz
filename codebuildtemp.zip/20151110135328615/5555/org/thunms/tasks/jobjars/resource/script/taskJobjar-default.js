/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
/**
 * 
 * 这是代码生成出来的js，原则上不建议修改此文件.
 * 
 **/
var taskJobjarTreeGrid;
$(function() {
	taskJobjarTreeGrid = $('#taskJobjarTreeGrid').treegrid({
		url :  thunms.base()+'/tasks/jobjars/taskJobjar/treeGridList',
		title : '',
		fit : true,
		fitColumns : true,
		nowrap : false,
		animate : false,
		border : false,
		idField : 'id',
		treeField : 'name',
		frozenColumns : [ [ {
			title : 'id',
			field : 'id',
			width : 150,
			hidden : true
		}, {
			field : 'name',
			title : '名称',
			width : 180
		} ] ],
		columns : [ [
		{
			field : 'orderNumber',
			title : '排序',
			width : 150,
			sortable : true
			
		}, {
			field : 'parentId',
			title : '上级',
			width : 150,
			formatter : function(value, rowData, rowIndex) {
				return rowData.parentName;
			}
		}, {
			field : 'parentName',
			title : '上级菜单',
			width : 150,
			hidden : true
		}, {
			field : 'createUserName',
			title : '创建者',
			width : 150,
			sortable : true
		} , {
			field : 'createTime',
			title : '创建时间',
			width : 150,
			sortable : true
		}, {
			field : 'lastUpdateTime',
			title : '最后修改时间',
			width : 150,
			sortable : true
		} ] ],
		onContextMenu : function(e, row) {
			e.preventDefault();
			$(this).treegrid('unselectAll');
			$(this).treegrid('select', row.id);
			$('#menu').menu('show', {
				left : e.pageX,
				top : e.pageY
			});
		},
		onLoadSuccess : function(row, data) {
			/*var t = $(this);
			if (data) {
				$(data).each(function(index, d) {
					if (this.state == 'closed') {
						t.treegrid('expandAll');
					}
				});
			}*/
		},
		onExpand : function(row) {
			taskJobjarTreeGrid.treegrid('unselectAll');
		},
		onCollapse : function(row) {
			taskJobjarTreeGrid.treegrid('unselectAll');
		}
	});

});

function taskJobjarEdit() {
	var node = taskJobjarTreeGrid.treegrid('getSelected');
	if(node){
		 var p = parent.thunms.dialog({
             title : '修改信息',
             href : thunms.base() + '/tasks/jobjars/taskJobjar/update',
             width : $(document.body).width(),
             height : $(document.body).height(),
             buttons : [{
                         text : '保存',
                         handler : function() {
                             parent.thunms.confirm('请确认', '您要保存当前修改的信息？', function(r) {
                                         if (r) {
                                         	parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
                                             var f = p.find('#taskJobjarUpdateForm');
                                             f.form('submit', {
                                                         url : thunms.base() + '/tasks/jobjars/taskJobjar/updateSave?id=' + node.id,
                                                         onSubmit: function(){
	                                                            //验证表单,可以在此增加其他的验证。
																if(f.form("validate")){
																
																	return true;//返回true时表示验证通过
																}else{
																	parent.thunms.progress.close();//关闭提示窗口
																	return false;//返回false表示验证未通过
																}
														},
                                                         success : function(d) {
                                                             var json = $.parseJSON(d);
                                                             if (json.success) {
                                                            	 var parentNode=taskJobjarTreeGrid.treegrid('getParent', node.id);
                                     							if(parentNode&&parentNode!=null){
                                     								taskJobjarTreeGrid.treegrid('reload', parentNode.id);
                                     							}else{
                                     								taskJobjarTreeGrid.treegrid('reload');
                                     							}
                                                                 
                                                                 p.dialog('close');
                                                             }
                                                             parent.thunms.progress.close();
                                                             parent.thunms.show({
                                                                         msg : json.msg,
                                                                         title : '提示'
                                                                     });
                                                         }
                                                     });
                                         }
                                     });
                         }
                     }, {
                         text : '取消',
                         handler : function() {
                             parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                         if (r) {
                                             p.dialog('close');
                                         }
                                     });
                             
                         }
                     }],
             onLoad : function() {
                 var f = p.find('#taskJobjarUpdateForm');
                 var parentId=f.find("#parentId").combotree({  
                     url: thunms.base()+'/tasks/jobjars/taskJobjar/treeList'
                 });
                 f.form('load', thunms.base() + '/tasks/jobjars/taskJobjar/findByPrimaryKey?id=' + node.id);
             }
         });
		
		
	}else{
		 parent.thunms.show({
             msg : '请选择需要修改的数据',
             title : '提示'
         });
	}
}
function taskJobjarAppend() {
	var node = taskJobjarTreeGrid.treegrid('getSelected');
    var p = parent.thunms.dialog({
                href : thunms.base() + '/tasks/jobjars/taskJobjar/add',
                title : '新增信息',
                width : $(document.body).width(),
                height : $(document.body).height(),
                buttons : [{
                            text : '保存',
                            handler : function() {
                                parent.thunms.confirm('请确认', '您要保存当前新增的信息？', function(r) {
                                            if (r) {
                                            	parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
                                                var f = p.find('#taskJobjarAddForm');
                                                f.form('submit', {
                                                            url : thunms.base() + '/tasks/jobjars/taskJobjar/addSave',
                                                            onSubmit: function(){
	                                                            //验证表单,可以在此增加其他的验证。
																if(f.form("validate")){
																
																	return true;//返回true时表示验证通过
																}else{
																	parent.thunms.progress.close();//关闭提示窗口
																	return false;//返回false表示验证未通过
																}
															},
                                                            success : function(d) {
                                                                var json = $.parseJSON(d);
                                                                if (json.success) {
                                                                	if(node){
                                                                	var parentNode=taskJobjarTreeGrid.treegrid('getParent', node.id);
                                              							if(parentNode&&parentNode!=null){
                                              								taskJobjarTreeGrid.treegrid('reload', parentNode.id);
                                              							}else{
                                              								taskJobjarTreeGrid.treegrid('reload');
                                              							}
                                                                	}else{
                                                                		taskJobjarTreeGrid.treegrid('reload');
                                                                	}
                                                                	
                                                                    p.dialog('close');
                                                                }
                                                                parent.thunms.progress.close();
                                                                parent.thunms.show({
                                                                            msg : json.msg,
                                                                            title : '提示'
                                                                        });
                                                            }
                                                        });
                                            }
                                        });
                            }
                        }, {
                            text : '取消',
                            handler : function() {
                                parent.thunms.confirm('请确认', '您要取消当前操作吗？', function(r) {
                                            if (r) {
                                                p.dialog('close');
                                            }
                                        });
                                
                            }
                        }],onLoad : function() {
                            var f = p.find('#taskJobjarAddForm');
                          var parentId=f.find("#parentId").combotree({  
                                url: thunms.base()+'/tasks/jobjars/taskJobjar/treeList'
                            });
                          if(node){
                        	  parentId.combotree('setText',node.name);
                              parentId.combotree('setValue',node.id); 
                          }
                          
                        }
            });
}
function taskJobjarRemove() {
	var node = taskJobjarTreeGrid.treegrid('getSelected');
	if (node) {
		parent.thunms.confirm('询问', '您确定要删除【' + node.name + '】？', function(b) {
			if (b) {
				parent.thunms.progress({title:'提示',msg:'处理中,请等待....' });
				$.ajax({
					url : thunms.base()+'/tasks/jobjars/taskJobjar/delete',
					data : {
						id : node.id
					},
					cache : false,
					dataType : "json",
					success : function(r) {
						if (r.success) {
							taskJobjarTreeGrid.treegrid('remove', node.id);
							var parentNode=taskJobjarTreeGrid.treegrid('getParent', node.id);
							if(parentNode&&parentNode!=null){
								taskJobjarTreeGrid.treegrid('reload', parentNode.id);
							}else{
								taskJobjarGrid.treegrid('reload');
							}
							parent.thunms.progress.close();
							parent.thunms.show({
								msg : r.msg,
								title : '提示'
							});
						} else {
							parent.thunms.show({
								msg : '删除失败!',
								title : '提示'
							});
						}
					}
				});
			}
		});
	}else{
		parent.thunms.show({
			msg : '请选择需要删除的数据！',
			title : '提示'
		});
	}
}
/**
 * 展开
 */
function taskJobjarExpandAll(){
	var node = taskJobjarTreeGrid.treegrid('getSelected');
	if (node) {
		taskJobjarTreeGrid.treegrid('expandAll', node.id);
	} else {
		taskJobjarTreeGrid.treegrid('expandAll');
	}
}
/**
 * 折叠
 */
function taskJobjarCollapseAll(){
	var node = taskJobjarTreeGrid.treegrid('getSelected');
	if (node) {
		taskJobjarTreeGrid.treegrid('collapseAll', node.id);
	} else {
		taskJobjarTreeGrid.treegrid('collapseAll');
	}
}
/**
 * 刷新
 */
function taskJobjarReload(){
	taskJobjarTreeGrid.treegrid('reload');
}

/**
 * 取消选中
 */
function taskJobjarUndoSelect(){
	taskJobjarTreeGrid.treegrid('unselectAll');
}
/**
 * 查询
 */
function taskJobjarDataSearch(){
	thunms.progress({title:'提示',msg:'查询中....' });
		$.ajax({
				type : "POST",
				url : thunms.base() + '/tasks/jobjars/taskJobjar/treeGridList',
				data : $("#taskJobjarDataSearchForm").serializeObject(),
				dataType : "json",
				success : function(data) {
					taskJobjarTreeGrid.treegrid('loadData', data);
					thunms.progress.close();
				}
		});
}
