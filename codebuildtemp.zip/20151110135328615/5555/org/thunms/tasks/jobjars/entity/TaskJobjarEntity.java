package org.thunms.tasks.jobjars.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.thunms.framework.entity.EntitySupport;
/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
@Entity
public class TaskJobjarEntity extends EntitySupport {

	private String  name;
	@OneToOne
	private TaskJobjarEntity parent;
	@OneToMany(cascade=CascadeType.ALL,targetEntity=TaskJobjarEntity.class,mappedBy="parent")
	@OrderBy(value="orderNumber asc")
	List<TaskJobjarEntity> childs=new ArrayList<TaskJobjarEntity>();
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public TaskJobjarEntity getParent() {
		return parent;
	}
	public void setParent(TaskJobjarEntity parent) {
		this.parent = parent;
	}
	public List<TaskJobjarEntity> getChilds() {
		return childs;
	}
	public void setChilds(List<TaskJobjarEntity> childs) {
		this.childs = childs;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	

}
