package org.thunms.tasks.jobjars.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thunms.framework.controller.ControllerDataGrid;
import org.thunms.framework.controller.ControllerTreeGrid;
import org.thunms.framework.model.DataGrid;
import org.thunms.framework.model.DataGridJson;
import org.thunms.framework.model.Json;
import org.thunms.framework.model.TreeNode;
import org.thunms.framework.service.ServiceDefault;
import org.thunms.tasks.jobjars.entity.TaskJobjarEntity;
import org.thunms.tasks.jobjars.model.TaskJobjar;
import org.thunms.tasks.jobjars.service.TaskJobjarService;
/**
 * 任务资源管理
 * 任务资源管理
 * 任务资源维护
 */
@Controller
@RequestMapping("/tasks/jobjars/taskJobjar")
public class TaskJobjarController extends ControllerTreeGrid<TaskJobjarEntity,TaskJobjar> {
	
	private static final Logger logger =LoggerFactory.getLogger(TaskJobjarController.class);

	public TaskJobjarController() {
		super("tasks", "jobjars", "taskJobjar");
		logger.debug("执行模块初始化"+this.getRerutnURL(""));
	}
	
	@Autowired
	private TaskJobjarService taskJobjarService;

	@Override
	protected ServiceDefault<TaskJobjarEntity, TaskJobjar> getBaseService() {
		return this.taskJobjarService;
	}
	

}
